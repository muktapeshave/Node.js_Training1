var express= require('express')

var app = express()

var ejs= require('ejs')

//we have to set ejs as view engine

app.set('view engine','ejs')
//set body parser: to read data from request body

//whenever we will post data from form it will be in the form of urlencoded

app.use(express.urlencoded())

var users=[{username:'Rutuja',userid:10},{username:'Nandik',userid:20},{username:'Shubham',userid:30}]

app.get('/',function(req,res){

    //res.send()
    //res.sendFile()
//it will search a given ejs file under Views folder
    //res.render('index.ejs',{username:'Rutuja',userid:10}) //render is used to return ejs file as response

    res.render('users.ejs',{userArray:users})
})

app.get('/adduser',function(req,res){

    //show create user form
    res.render('createUser.ejs')
})


app.post('/postuser',function(req,res){

    //req.query.
    //req.params.
   // console.log(req.body)

    var username=req.body.username
    var userid= req.body.userid


    users.push({username,userid})

    res.redirect('/')
    //console.log(users)

    //console.log("postuser handler is called...")

    //We need to get avlues from form fields
    //Then create new user object
    //And add it in exiting array
})

app.listen(3000,function(){

    console.log("Server started...")
})
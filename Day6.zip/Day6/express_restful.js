var express= require('express')

var app= express()

var router= express.Router()

router.route('/books')
.get((req,res)=>{
    res.send("Sending List of books...")

   // res.json()
})
.post((req,res)=>{

})

router.route("/products/:productid") // /products/100
.get((req,res)=>{

    //req.params.productid

})
//we have to connect app with router object

app.use('/',router)
//app.use('/books',router)
app.listen(3000,function(){
    console.log("Server started...")
})
//1. get:"/books""
//2. post:"/books""
//3. put:"/books""
//4. delete:"/books""
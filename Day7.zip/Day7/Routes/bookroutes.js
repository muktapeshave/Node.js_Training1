var express= require('express')

var book= require('../Model/book')

var router= express.Router()

router.route('/books')
.get((req,res)=>{
    //we have to fetch all documents from books collection
    book.find({}).then(books=>{
        res.json(books) 
    })
    .catch(err=>{
        res.send(err)
    })
 
})
.post((req,res)=>{
       //read data from request body
       // console.log(req.body)
       var book1=new book(req.body)
       book1.save().then(()=>{
            res.status(201).send("Data is saved")

       })
       .catch((err)=>res.send(err))

})

router.route("/books/:isbn") // /books/isbn123
.get((req,res)=>{

   var isbn=   req.params.isbn


   book.findOne({isbn}).then(data=>{
        res.send(data)
        //check if data is empty and then send status code as 404 and some error

   })
   .catch((err)=>res.send(err))

})

.put((req,res)=>{
    var isbn=   req.params.isbn

    book.findOneAndUpdate({isbn},req.body)
    .then(()=>res.send("Record update"))
    .catch((err)=>res.send(err))

})

.delete((req,res)=>{
    var isbn=   req.params.isbn

    book.findOneAndRemove({isbn}).then(()=>res.send("Record Deleted"))
    .catch((err)=>res.send(err))

})

module.exports= router
var mongoose= require('mongoose')


var Schema= mongoose.Schema

var bookSchema= new Schema({

    name:{type:String,required:true},
    isbn:{type:String},
    author:{type:String},
    pages:{type:Number}
})

//1st para: name of model
//2nd para: Schema name
//3rd para: name of mongodb collection
//var book= mongoose.model('book',bookSchema)//if 3rd para is not specified it will take plural form of schema name and will consider it as collection
var book= mongoose.model('book',bookSchema,'books')

module.exports=book
//book: with this model object we will perform all CRUD operations
function readFile(processFileContents){
    console.log('Reading a large file');
          setTimeout(function(){                   // by default async in nature
            for(var i=0;i<9999999999;i++){
                
            }

           // return "Some Data"    

           processFileContents("Some Data")
        },0) 
   
     
}
function processFileContents(filecontents){
    console.log('Processing File Contents'+filecontents);
}

function computeSum(){
    console.log('Computing Sum of numbers');
}
// async methods will not return us data directly
//There r diff ways of handling data from async methods

// Callback  : pass  function which is supposed to get executed after
//finishing async call as i/p parameter to another function

console.log('Program callstack starts');
var fileData=readFile(processFileContents);
//processFileContents(fileData);
computeSum();
console.log('Program callstack Ends');
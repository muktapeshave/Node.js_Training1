
 var os=  require('os')// require will return ref vriable using which we can access
 //all exported functionality


 console.log( os.hostname())
 console.log( os.freemem())
 console.log( os.homedir())

   var cal=  require('./Calculator/cal1')

   var cal2 = require('./Calculator/cal2')

   console.log( cal.add1(10,20))
   console.log( cal.sub1(10,5))



   console.log(cal2.Multiply(5,4))
   console.log(cal2.Division(16,4))
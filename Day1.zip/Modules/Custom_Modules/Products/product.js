

module.exports= function(){

    return "Product Detail...."
}

// function getProductDetails(){

//     return "Product Detail...."
// }

//module.exports.getProduct=getProductDetails
//Anonymous export
//using this anonymous export one member will be exported at a given time
//module.exports=getProductDetails
//module.exports is having direct single member available which is nothing but getProductDetails

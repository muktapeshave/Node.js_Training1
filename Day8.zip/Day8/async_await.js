
const fsPromises = require('fs').promises;


async function readData(){

    try
     {
         var result= await fsPromises.readFile('Data1.txt','utf-8')
    
    //  console.log("-----",result)

     return result
    }
     catch(err){
    
    console.log(err)
    }
    }

    
   readData().then((data)=>console.log(data))

    // console.log(result)


    // (async () => {
    //     console.log(await readData())
    //   })()
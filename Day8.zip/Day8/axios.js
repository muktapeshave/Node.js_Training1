process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '0';


const axios = require('axios'); // consume APIs

axios
  .get('https://jsonplaceholder.typicode.com/album/1/photos')
  .then(res => {
    console.log(`statusCode: ${res.status}`);
    console.log(res.data);
  })
  .catch(error => {
    console.error(error);
  });
var chaiaspromise = require('chai-as-promised');
var chai = require('chai');
var should = require('chai').should();
chai.use(chaiaspromise);
const resolvingPromise = new Promise( (resolve) => {
    resolve(10);
  });
var promiseObj2 = new Promise((resolve,reject)=>{
    reject("error");
});
promiseObj2.catch(err=>console.log(err));
  it('promise resolve', () => {
    return resolvingPromise.should.eventually.equal(10);  
    //return Promise.resolve(2 + 2).should.eventually.equal(4);
  });
	it('promise reject', () => {       
        return expect(promiseObj2).to.be.rejectedWith("error");
      }); 
	  it('resolves as promised', function() {
    return expect(Promise.resolve('woof')).to.eventually.equal('woof');
});
	  it('rejects as promised', function() {
        return expect(Promise.reject('caw')).to.be.rejectedWith('caw');
    });


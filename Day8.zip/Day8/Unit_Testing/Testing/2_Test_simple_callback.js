//https://blog.logrocket.com/a-quick-and-complete-guide-to-mocha-testing-d0e0ea09f09d/

//https://masteringjs.io/tutorials/mocha/async
var assert = require('assert');
var fs = require('fs');
describe('callback tests:', function () {
    it('simple_callback1', (done) => {

        fs.readFile('Data1.txt', 'utf-8', function (err, data) {
            if (err)
                done(err);
            else {
                assert.equal('Hello World', data);
                console.log('data1' + data);
                done();
            }
        });
        console.log('test1 finished ');
    })

    // it('simple_callback2', (done) => {
    //     fs.readFile('test/Data2.txt', 'utf-8', function (err, data) {
    //         assert.equal('Hello Mocha', data);
    //         console.log('data2' + data);
    //         done();
    //     });
    //     console.log('test2 finished');
    // })
});
/*
Inroder to prove why the done() needs to be invoked, 
try to remove done() from argument list and also dont invoke it. 
You can see the output wherein both the tests finish exection and 
then the output is displayed. Which means, asserts will get called 
even before the ASync call has completed. */
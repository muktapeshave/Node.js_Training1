var assert = require('assert');
var should = require('chai').should();
var nums = [3,5,6];
describe("should tests",function(){
    it('Test length of string', function () {    
        var data="Hello";
        data.should.have.length(5);
      });
      it("Check boolean",function(){
        var islogged=true;
        islogged.should.be.true;
      })
      it('array test1',function(){
        nums.should.have.lengthOf(3);
        nums.should.contain(5);
       })
})
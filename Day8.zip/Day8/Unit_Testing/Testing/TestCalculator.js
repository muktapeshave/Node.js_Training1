var assert = require('assert')

var calculator= require('../Calculator/cal1')

//describe : is a way to group our tests in Mocha
describe('Calculator',function(){

    //We will write multiple Test Cases

    //it : used for individual test case

    it('addition',function(){
        //write assertions
        assert.equal(calculator.add(3,2),5)
    })

    it('subtraction',function(){
        //write assertions

        assert.equal(calculator.sub(7,3),4)
    })

})
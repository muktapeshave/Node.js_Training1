var assert = require('assert');
var request = require('request');
var data="";
describe('http tests:', function() {
    it('callback', function(done) {
      request.get('https://jsonplaceholder.typicode.com/users/1', 
      function(err,res,body) {
     
      assert.equal(200, res.statusCode);
        var obj = JSON.parse(body);
        console.log("name: " + obj.name);
        assert.equal("Leanne Graham",obj.name);
        done();
        });          
    });
  });
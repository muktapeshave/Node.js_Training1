//https://www.chaijs.com/
var assert = require('assert');
var expect = require('chai').expect;
var nums = [3,5,6];
describe("expect tests",function(){
    it('Test length of string', function () {  
        var data="Hello";
        assert.equal(data.length, 5);
        expect(data.length).to.be.equal(5);
        expect(data).to.have.lengthOf(5);        
      });
      it("Check array",function(){
        expect(nums.length).to.be.equal(3);
        expect(nums[4]).to.be.undefined;       
      })
      it("Check boolean",function(){
        var islogged=true;
        expect(islogged).to.be.true;
      })
})

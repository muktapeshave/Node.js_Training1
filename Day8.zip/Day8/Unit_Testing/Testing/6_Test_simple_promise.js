var assert = require('assert');
const resolvingPromise = new Promise( (resolve) => {
    resolve('promise resolved');
  });

  //Approach1: Call 'done' at the end of the assertions. 
  //Problem with this approach is: it throws timeout error 
  //when testcase fails.
  it('resolves1', (done) => {
    resolvingPromise.then((result) => {
        assert.equal(result,'promise resolvedd');
        done();
      });
    });

    //Approach2: Instead of passing 'done', return the promise
    //This ensure that failing error is displayed appropriately.
    it('resolves2', () => {
        return resolvingPromise.then( (result) => {
            assert.equal(result,'promise resolvedd');
        });
      });

      //Approach3: Use finally
      it('resolves3', (done) => {
        resolvingPromise.then( (result) => {
            assert.equal(result,'promise resolved');
        }).finally(done);
      });
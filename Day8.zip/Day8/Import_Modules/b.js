
var mathsjs= require('mathjs')

console.log( mathsjs.add(30,10))

console.log( mathsjs.sqrt(64))

console.log( mathsjs.cube(7))

//Re-export
//https://bobbyhadz.com/blog/javascript-export-from-another-file#:~:text=To%20re%2Dexport%20values%20from,file%20that%20re%2Dexported%20them.
import * as mathjs from 'mathjs'



import Test,{ sqrt, square } from './app.js'

const a = sqrt(4);
const b = square(2);
console.log(a);
console.log(b);
Test()

 console.log( mathjs.sqrt(9))
export const sqrt = Math.sqrt;
export function square(x) {
    return x * x;
}

export default function Test(){
    console.log("test is called..")
}


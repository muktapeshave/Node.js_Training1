var http= require('http')


//createServer will take on i/p parameter which is nothing but http handler
//this httpHandler will be called for every request
//Every http handler should have 2 i/p parameter: request,response
//https://in.bookmyshow.com/dramas/pune 

 const server= http.createServer((request,response)=>{
    //this http handler will be called for each and every request

    if(request.url == "/users")
    {

        if(request.method == "GET")
            response.write("Sending List of users")

    }
    else if(request.url == "/employees")
    response.write("Sending List of employees")
    else
    response.write("Welcome to Persistent!!")

    response.end()

 })

 server.listen(3000,function(){
    console.log("Server STarted...")
 })
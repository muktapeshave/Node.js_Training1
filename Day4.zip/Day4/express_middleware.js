
var express= require('express')

//create new express by

var app = new express()

// using app we will configure different routes

//products
function Logging(req,res,next){
    console.log(req.url+" "+req.method+" is called at "+Date.now())
    var flag= false
    if(flag)
        next() // this will call next middleware or if its last middleware it will call actual handler
    else
        res.send("User is not authenticated..") 

}
app.get('/', Logging,function(req,res){

    res.send("Welome to Persistent!!")
})
app.get('/products',Logging,function(req,res){
   // console.log(req.url+" "+req.method+" is called at "+Date.now())
    res.send("Sending List of products")
})

app.get('/items',Logging,function(req,res){
    //console.log(req.url+" "+req.method+" is called at "+Date.now())

    res.send("Sending List of items")
})

app.listen(3000,function(){
    console.log("Server started..")
})

var express= require('express')

//create new express by

var app = new express()

// using app we will configure different routes


app.get('/',function(req,res){

    res.send("Welome to Persistent!!")
})


app.get('/users',function(req,res){
    //users?username="Shreyas"

    var name= req.query.username

    

    res.send("Sending List of users "+ name)
})

app.post('/users',function(req,res){
    res.send("Creae new user")
})

app.get('/products',function(req,res){
    res.send("Sending List of products")
})

app.get('/items',function(req,res){
    res.send("Sending List of items")
})

app.listen(3000,function(){
    console.log("Server started..")
})

var express= require('express')

//create new express by

var app = new express()

// using app we will configure different routes


// function Logging(req,res,next){
//     console.log(req.url+" "+req.method+" is called at "+Date.now())
//     var flag= true
//     if(flag)
//         next() // this will call next middleware or if its last middleware it will call actual handler
//     else
//         res.send("User is not authenticated..") 

// }

//app.use(): this function is used to mount/add middlewares(user defined middlewares/in built middlewares)


app.use(function(req,res,next){

    console.log(req.url+" "+req.method+" is called at "+Date.now())
var flag= true
if(flag)
    next() // this will call next middleware or if its last middleware it will call actual handler
else
    res.send("User is not authenticated..") 
})


app.get('/', function(req,res){

    res.send("Welome to Persistent!!")
})


app.get('/products',function(req,res){
   // console.log(req.url+" "+req.method+" is called at "+Date.now())
    res.send("Sending List of products")
})


app.get('/items',function(req,res){
    //console.log(req.url+" "+req.method+" is called at "+Date.now())

    res.send("Sending List of items")
})

app.listen(3000,function(){
    console.log("Server started..")
})
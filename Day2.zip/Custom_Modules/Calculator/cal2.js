function Multiply(num1,num2){

    return num1*num2

}


function Division(num1,num2){
    return num1/num2
}

// module.exports.Multiply=Multiply
// module.exports.Division=Division
//var emp1={FName:"Mukta",LName:"L"}


var FName="Mukta"
var LName="P"

var emp1={FName:FName,LName:LName}

var emp2={FName,LName} // Key name is FName and variable which holds value for that key is also FName


// module.exports={
//         Multiply:Multiply,
//         Division:Division
// }


module.exports={
    Multiply,
    Division
}
function add(num1,num2){
    return num1+num2
}



function sub(num1,num2){
    return num1-num2
}


//exporting modules
//named export

//module.exports:it is inbuilt object available for every js file


module.exports.add1=add  //named export

module.exports.sub1=sub  //named export
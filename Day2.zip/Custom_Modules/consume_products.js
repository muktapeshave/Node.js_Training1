

   var product=  require('./Products/product')
//module.exports=getProductDetails

console.log( product())

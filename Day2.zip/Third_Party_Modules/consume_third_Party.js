 var mathjs=   require('mathjs')


 console.log(mathjs.sqrt(16))
 console.log(mathjs.square(12))
 console.log(mathjs.log(1000,10))



var fs= require('fs')


fs.readdir('.',(err,contents)=>{


    if(err)
    console.log(err)
    else{

        for(let i in contents){

            console.log(contents[i])
        }
    }
})
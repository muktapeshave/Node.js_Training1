
var fs= require('fs')

// var emp1=["abc","def"]

//WriteFIle will always overwrite data

fs.writeFile("NewData.txt","Welcome To Persistent FileSystems !!",function(err){


    if(err)
    console.log(err)
    else
    console.log("Data written to FIle !!")
})


fs.appendFile("NewData.txt","APpend Text to file",function(err){
    if(err)
    console.log(err)
    else
    console.log("Data appended...")
})
var fs = require('fs')


console.log("Program started..")
try
{
 var data=fs.readFileSync("Data.txt")
 console.log(data.toString())
}

catch(e){
    
}

 console.log("Do something else...")


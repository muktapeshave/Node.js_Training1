var fs= require('fs')


fs.stat('Data.txt',function(err,status){

    if(err)
        console.log(err)

     else{
            console.log("Size "+status.size)
            console.log("Size "+status.isFile())
            console.log("Size "+status.isDirectory())
            console.log("Size "+status.birthtime)
            
     }   
})
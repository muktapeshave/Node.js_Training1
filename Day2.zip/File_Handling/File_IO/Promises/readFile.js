var fs= require('fs').promises // we r getting promisified version of fs module



fs.readFile('Data.txt','utf-8')
.then(data=>console.log(data))
.catch(err=>console.log(err))



// fs.readFile('Data.txt','utf-8',(err,data)=>{

//     if(err)
//     console.log(err)
//     else
//     console.log(data)
//  })

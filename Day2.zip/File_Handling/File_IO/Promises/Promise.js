

//Promise contr taken one argument which is a function .That function takes 2 i/p parameters
// resolve,reject

//If promise is fulfilled resolve() will be called
//else reject() will be called
var promise= new Promise((resolve,reject)=>{

    var flag= false

    if(flag)
        resolve("Promise is resolved..")

     else
        reject("Promise is rejcted..")   
})


// How to consume promise
// if promise is resolved then will be called
//if promise is rejcted cathc will be called
promise.then(data=>{
    console.log(data)
}).catch((err)=>console.log(err))
var fs = require('fs')

fs.readdir('.',function(err,files){

    if(err)

        console.log(err)

        else
        {

            for(var i in files){

                //call anothe async method
                    fs.stat(files[i],function(err,stat){

                        if(err)
                            console.log(err)

                          else{
                            stat.isDirectory()  
                                fs.rmdir()
                          }
                    })
            }
        }

})
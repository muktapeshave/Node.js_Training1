var fs = require('fs')


if(fs.existsSync('testData')){


    console.log("Dir already exists ,hence deleting it")

    fs.rmdirSync('testdata')
    fs.mkdirSync('tsetdata')


    
}
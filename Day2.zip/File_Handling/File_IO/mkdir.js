var fs= require('fs')


fs.mkdir("UserData",function(err){

    if(err)
        console.log(err)

    else
        console.log("Dir is created..")

})



fs.rmdir("UserData",function(err){
    if(err)
    console.log(err)
    else
    console.log("Directory removed..")
})
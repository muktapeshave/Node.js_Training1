 var fs= require('fs')

 //readFile() is async in nature
 //

 console.log("Program starts..")

 // 1st parameter : name of file
 //2nd parameter:Diff options,encoding etc.
 //3rd parameter: callback function: will be executed after finishing this async call
        //callback function: 1st parameter will be err object
                            //2nd parameter is actual data
             //These callabcks are called error first callback               
//  fs.readFile('Data.txt','utf-8',function(err,data){

//     if(err)
//     console.log(err)
//     else
//     console.log(data)
//  })


fs.readFile('Data.txt','utf-8',(err,data)=>{

    if(err)
    console.log(err)
    else
    console.log(data)
 })

 console.log("Compute Sum.....")
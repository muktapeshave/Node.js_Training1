var event= require('events')


var eventEmitter= new event.EventEmitter()


eventEmitter.on('Register',function(user){
    console.log("Send Email to User..."+user.username+" "+user.role)
})


eventEmitter.on('Register',function(user){
    console.log("Send SMS..."+user.username+" "+user.role)
})

eventEmitter.on('Register',function(user){
    console.log("Insert record into DB..."+user.username+" "+user.role)
})


eventEmitter.emit('Register',{username:"Mukta",role:"Admin"}) 



 //emitting event.Publishing event



//btn.onClick=fucntion(event){}
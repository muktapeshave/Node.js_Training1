var events= require('events')

var eventEmitter= new events.EventEmitter()


var totalAmount=1000

function WithdrawAmount(amount){

    totalAmount=totalAmount-amount

    eventEmitter.emit('Withdraw',totalAmount)
    //it should just emit an event 
    //'withdraw'
   // sendSMS(totalAmount)
    //sendEmail(totalAmount)
    //updatePassbook(totalAmount)
}



function sendSMS(amount){
    console.log("send SMS...."+amount)
}


function sendEmail(amount){
    console.log("send Email..."+amount)
}

function updatePassbook(amount){
    console.log("Update passbook.."+amount)
}

//eventEmitter.on('Withdraw',sendEmail)
eventEmitter.on('Withdraw',sendSMS)
eventEmitter.on('Withdraw',updatePassbook)

WithdrawAmount(300)
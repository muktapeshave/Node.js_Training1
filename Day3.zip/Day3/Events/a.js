const yargs = require('yargs');
 yargs
 .command({
     cmd:'add',
     desc: 'adding book',
     builder:(yargs)=>{
         return yargs
         .option('title',{type:'string',demandOption:true})
         .option('description',{type:'string'})
         .option('price',{type:'number',demandOption:true})
     },
     handler:(argv)=>{
         console.log('Adding a Book');
         console.log(argv.title);
         console.log(argv.description);
         console.log(argv.price);
     }
 })
 .command({
     cmd: 'remove',
     desc: 'removing book',
     builder:(yargs)=>{
         return yargs
         .option('title',{type:'string',demandOption:true})
     },
     handler:(argv)=>{
         console.log("Removing a Book");
         console.log(argv.title);
     }
 })
 .argv;

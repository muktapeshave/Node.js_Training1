
var fs = require('fs')

//When we have to perform multiple operations on a file



//fd: a file descriptor which will be used for subsequent file operation
fs.open('Data1.txt','r+',function(err,fd){

    if(err)
    console.log(err)

    fs.readFile(fd,'utf-8',function(err,fileData){

        console.log(fileData)
    })


    fs.writeFile(fd,"File Sytem Module Data",function(err){

        console.log("Written to FIle")
    })
})
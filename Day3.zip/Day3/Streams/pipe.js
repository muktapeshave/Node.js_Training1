
// var fs = require('fs');
// var readStream = fs.createReadStream('Data.txt');
// var writeStream = fs.createWriteStream('Copy.txt');
// readStream.on('data',function(data){
//     console.log("--------------------------");
//     console.log(data.toString());
//     writeStream.write(data.toString());

// });

// readStream.on('end',function(){
//     console.log('Finished writing');
//     writeStream.end();
// });



var fs = require('fs')

var readbleSTream= fs.createReadStream('Data.txt')
var writableStream= fs.createWriteStream('DataCOpy.txt')


readbleSTream.pipe(writableStream)
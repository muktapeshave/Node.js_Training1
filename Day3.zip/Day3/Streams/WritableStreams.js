var fs = require('fs')

var stream= fs.createWriteStream('out.txt',{flags:'a'})

stream.write("Hello Node.js!!")
stream.write("We r learning streams !!")

stream.end()//it is required to flush data to the system


stream.on('finish',function(){
    console.log("Write is complete now!!")
})


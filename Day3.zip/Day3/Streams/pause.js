var fs = require('fs')

 var readableStream = fs.createReadStream('Data.txt',{encoding:'utf-8',highWaterMark:100})



 readableStream.on('data',(chunk)=>{


    console.log(chunk)

    readableStream.pause()

    console.log("Flow Paused here !!")


    setTimeout(()=>{

                readableStream.resume()
    },4000)
 })
var fs= require('fs')


//by default chunk size is 64 KB
//highWaterMark :using this we can specify chunk size
var readStream=  fs.createReadStream('Data.txt',{encoding:'utf-8',highWaterMark:100})

//Streams work on concept of events

  // event(click):eventHandler(Handler)
  // btn1.onClick=function(){}

//UI: user action:click,mousedown etc...

//Streams: it will emit different events

//'data': this event is emitted when data/chunk is available in memory to read

//In Node.js to subscribe for any event we will use 'on' method


readStream.on('data',function(datachunk){
        console.log("---------------------")

        console.log("Chunk od data "+datachunk)
})


//end:this is emitted when no more data is available

readStream.on('end',function(){
    console.log("Finished Reading")
})

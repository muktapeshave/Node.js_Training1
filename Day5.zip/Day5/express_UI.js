var express= require('express')

var logger = require('morgan')


//Create new app by instantiating express

var app = express()


app.use(logger('dev'))

//Serving static files

app.use(express.static('Public'))

app.get('/',function(req,res){

    //res.send() : we can send string,json,object...
//__dirname: it will give current path
    //console.log(__dirname)
    //res.sendFile("D:/Course.../Views/home.html")
//var user1={username:'Bikash',userid:10}
    res.sendFile("home.html")
})


app.get('/products',function(req,res){

    //res.send() : we can send string,json,object...
//__dirname: it will give current path
    console.log(__dirname)
    //res.sendFile("D:/Course.../Views/home.html")

    res.sendFile("Product.html")
})

app.get('/adduser',function(req,res){

            res.send("We will add User here !!!")
})
app.listen(3000,function(){

    console.log("Server is running...")

})
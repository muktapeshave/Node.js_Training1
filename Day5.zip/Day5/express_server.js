
var express= require('express')
var morgan= require('morgan')
var app = new express()
//configure morgan for handling logs

app.use(morgan('dev'))

//create new express by


// app.use(function(req,res,next){
//     console.log("log request")
//     next()
// })


app.get('/', function(req,res){

    res.send("Welome to Persistent!!")
})


app.get('/products',function(req,res){
   // console.log(req.url+" "+req.method+" is called at "+Date.now())
    res.send("Sending List of products")
})


app.get('/items',function(req,res){
    //console.log(req.url+" "+req.method+" is called at "+Date.now())

    res.send("Sending List of items")
})

//this will be called for client related errors
app.use(function(req,res,next){

        res.status(404).send("Request is not correct")
})

// //this will be called for internal server error
app.use(function(err,req,res,next){
        res.status(500).send("There is some issue at server side !!")
})

app.listen(3000,function(){
    console.log("Server started..")
})
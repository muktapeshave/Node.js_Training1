var express= require('express')

var app = express()

var ejs= require('ejs')

//we have to set ejs as view engine

app.set('view engine','ejs')

var users=[{username:'Rutuja',userid:10},{username:'Nandik',userid:20},{username:'Shubham',userid:30}]

app.get('/',function(req,res){

    //res.send()
    //res.sendFile()
//it will search a given ejs file under Views folder
    //res.render('index.ejs',{username:'Rutuja',userid:10}) //render is used to return ejs file as response

    res.render('users.ejs',{userArray:users})
})

app.get('/adduser',function(req,res){

    res.send("We will add User here !!!")
})


app.listen(3000,function(){

    console.log("Server started...")
})